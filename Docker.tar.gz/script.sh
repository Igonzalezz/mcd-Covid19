#!/bin/sh

get_Database ()
{
	curl -O datosabiertos.salud.gob.mx/gobmx/salud/datos_abiertos/datos_abiertos_covid19.zip && \
	unzip datos_abiertos_covid19.zip && \
	mv *COVID19MEXICO.csv untouch_data.csv
}

get_Dictionary ()
{
	curl -O datosabiertos.salud.gob.mx/gobmx/salud/datos_abiertos/efe/diccionario_datos_efe.zip && \
	unzip diccionario_datos_efe.zip
}

formatFile() 
{
	csvcut -c 6,8,9,11,12,13,16,25,36 untouch_data.csv > almost_clean_data.csv && \
	csvgrep -c ENTIDAD_RES -m "26" almost_clean_data.csv | csvgrep -c MUNICIPIO_RES -m "18" almost_clean_data.csv | csvgrep -c CLASIFICACION_FINAL -r "[123]" almost_clean_data.csv | csvcut -c 1,4,5,6,7,8,9 almost_clean_data.csv > clean_data.csv && \
	csvgrep -c FECHA_DEF -m "9999-99-99" clean_data.csv > Sonora_Hipertensos_Confirmados.csv && \
	csvgrep -i -c FECHA_DEF -m "9999-99-99" clean_data.csv > Sonora_Hipertensos_Confirmados_Defunciones.csv
	#Columns#
	#1: SEXO
	#2: ENTIDAD_RES
    #3: MUNICIPIO_RES
    #4: FECHA_INGRESO
    #5: FECHA_SINTOMAS
    #6: FECHA_DEF
    #7: EDAD
    #8: HIPERTENSION
    #9: CLASIFICACION_FINAL
}
cleanup ()
{
	find . -name \*.zip -delete && \
	rm -f untouch_data.csv almost_clean_data.csv clean_data.csv
}

rm -rf Data?

mkdir "Data" && cd "$_"  && \

get_Database

get_Dictionary

formatFile

cleanup

exec $SHELL
